package com.example.ejemplorecyclerview2024.activities;

import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ejemplorecyclerview2024.R;
import com.example.ejemplorecyclerview2024.adapters.AdaptadorEquipos;
import com.example.ejemplorecyclerview2024.model.Equipo;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity  {
    // DATOS
    static List<Equipo> listaEquipos;
    // VIEWS
    private RecyclerView rvListaEquipos;

    // ADAPTADOR
    private AdaptadorEquipos adaptador;

        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        cargarDatos();
        initReferences();
        configurarRecyclerView();

    }


    /**
     * Método que carga los datos en el arrayList de equipos
     */
    private void cargarDatos() {
        listaEquipos = new ArrayList<>();
        // extraer datos del XML
        String[] nombres = getResources().getStringArray(R.array.nombre_equipo);
        int[] puntos = getResources().getIntArray(R.array.puntos_equipo);
        TypedArray array = getResources().obtainTypedArray(R.array.escudo_equipo);
        Drawable[] imagenesEscudo = new Drawable[array.length()];
        for (int i = 0; i < array.length(); i++) {
            imagenesEscudo[i] = array.getDrawable(i);
        }
        // rellenar el ArrayList
        for (int i = 0; i < nombres.length; i++) {
            listaEquipos.add(new Equipo(nombres[i], imagenesEscudo[i], puntos[i], 22));
        }
    }


    /**
     * Método que obtiene las referencias a las vistas del XML
     */
    private void initReferences() {

        rvListaEquipos = findViewById(R.id.rvListaEquipos);
    }


    /**
     * Método que configura la RecyclerView
     */
    private void configurarRecyclerView() {
        adaptador = new AdaptadorEquipos(listaEquipos);
        rvListaEquipos.setAdapter(adaptador);
        // asigno la distribución en forma de lista (no de grid)
        /* también se podría hacer por XML (aunque tienen menos posibilidades de configuración)
           y sería con esta propiedad:

           app:layoutManager="androidx.recyclerview.widget.LinearLayoutManager"

         */
        rvListaEquipos.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
    }

}