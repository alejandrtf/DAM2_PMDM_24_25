package com.example.ejemplorecyclerview2024.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ejemplorecyclerview2024.R;
import com.example.ejemplorecyclerview2024.model.Equipo;

import java.util.List;

public class AniadirEquipoActivity extends AppCompatActivity implements View.OnClickListener {
    // CONSTANTS
    public static final String IMAGEN_ESCUDO = "IMAGEN_ESCUDO";
    public static final String RESULTADO_INSERCION = "resultado insercion";
    public static final String EXTRA_POSICION_INSERCION = "extra_posicion";
    // VIEWS
    ImageView ivEscudo;
    CheckBox cbSinFoto;
    Button btAniadirFoto, btAniadirEquipo;

    // LAUNCHER para la cámara de fotos
    private ActivityResultLauncher<Void> tomarFotoLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_aniadir_equipo);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initReferences();
        setListenersToCheckBoxes();
        setListenersToButtons();
        configurarLauncherTomarFoto();
    }

    /**
     * Método que obtiene las referencias a las vistas XML
     */
    private void initReferences() {
        ivEscudo = findViewById(R.id.ivEscudoAniadir);
        btAniadirFoto = findViewById(R.id.btAniadirFoto);
        cbSinFoto = findViewById(R.id.cbSinFoto);
        btAniadirEquipo = findViewById(R.id.btAniadirEquipo);
    }


    /**
     * Método que asigna los listeners a los checkBoxes
     */
    private void setListenersToCheckBoxes() {
        cbSinFoto.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // activo el botón añadir foto cuando esté el checkbox desmarcado o lo desactivo en caso contrario
                btAniadirFoto.setEnabled(!isChecked);
                if (isChecked) {
                    // asigno foto genérica al ImageView del escudo
                    ivEscudo.setImageResource(R.drawable.generica);
                    ivEscudo.setTag(R.drawable.generica);  //lo necesitaré después saber qué imagen está
                } else {
                    // quito la foto del ImageView sólo si es la genérica, porque puede ser que
                    // hubiese una foto tomada con la cámara
                    if ((int) ivEscudo.getTag() == R.drawable.generica) {
                        ivEscudo.setImageDrawable(null);
                    }
                }
            }
        });
    }

    /**
     * Método que añade los listeners a los botones
     */
    private void setListenersToButtons() {
        btAniadirEquipo.setOnClickListener(this);
        btAniadirFoto.setOnClickListener(this);
    }


    /**
     * Método que configurar el launcher que permite lanzar la activity de la cámara de fotos
     * y recoger luego la foto en formato thumbnail
     */
    private void configurarLauncherTomarFoto() {
        tomarFotoLauncher = registerForActivityResult(
                new ActivityResultContracts.TakePicturePreview(),
                new ActivityResultCallback<Bitmap>() {
                    @Override
                    public void onActivityResult(Bitmap result) {
                        ivEscudo.setImageBitmap(result);
                    }
                }
        );
    }

    /**
     * Método que lanza la cámara del dispositivo y recoge la foto en formato thumbnail
     */
    private void tomarFoto() {
        tomarFotoLauncher.launch(null);
    }

    /**
     * Método que añade un equipo a la lista de equipos
     */
    private void aniadirEquipo() {
        Equipo equipo = crearEquipoFromDatosActivity();
        if (equipo != null) {
            int pos = buscarPosEquipo(MainActivity.listaEquipos, equipo.getPuntos());
            MainActivity.listaEquipos.add(pos, equipo);
            // desactivar botón añadir equipo
            btAniadirEquipo.setEnabled(false);
            // devolver los datos al mainActivity para actualizar adaptador
            Intent iResultadoInsercion = new Intent();
            iResultadoInsercion.putExtra(RESULTADO_INSERCION, "OK");
            iResultadoInsercion.putExtra(EXTRA_POSICION_INSERCION, pos);
            setResult(RESULT_OK, iResultadoInsercion);
            finish();
        }
    }

    /**
     * Método que crea un objeto Equipo a partir de los datos de los datos introducidos
     * en el formulario de Añadir Equipo.
     * Se comprueba que el nombre no sea vacío, escudo no vacío y si los puntos están en blanco se
     * ponen a 0;  nº jugadores se ponen a 0 siempre.
     *
     * @return un objeto Equipo con los datos del nuevo equipo o null si hay errores
     */
    private Equipo crearEquipoFromDatosActivity() {
        Equipo equipo = null;
        boolean error = false;
        // VIEWS
        EditText etNombre, etPuntos;

        // obtengo referencias para las nuevas views
        etNombre = findViewById(R.id.etNombreEquipoAniadir);
        etPuntos = findViewById(R.id.etPuntosAniadirEquipo);

        // comprobación errores
        if (etNombre.getText().toString().isEmpty()) {
            etNombre.setError(getString(R.string.error_introduce_nombre_equipo));
            error = true;
        }
        String puntos = etPuntos.getText().toString().isEmpty() ? "0" : etPuntos.getText().toString();
        if (ivEscudo == null || ivEscudo.getDrawable() == null) {
            Toast.makeText(this, "Debes elegir una imagen", Toast.LENGTH_SHORT).show();
            error = true;
        }

        if (!error) {
            equipo = new Equipo(etNombre.getText().toString(), ivEscudo.getDrawable(), Integer.parseInt(puntos), 0);
        }
        return equipo;
    }


    /**
     * Método que busca la pos adecuada para insertar un equipo nuevo en un ArrayList de Equipo
     * ordenado por los puntos de los equipos.
     *
     * @param listaEquipos el ArrayList con los equipos donde se busca la posición
     * @param puntos       los puntos que tiene el equipo cuya posición se busca
     * @return la posición correspondiente a ese equipo en la lista
     */
    private int buscarPosEquipo(List<Equipo> listaEquipos, int puntos) {
        for (Equipo equipo : listaEquipos) {
            if (equipo.getPuntos() < puntos) {
                return (listaEquipos.indexOf(equipo));
            }
        }
        return listaEquipos.size();
    }


    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        Bitmap fotoEscudo;

        super.onSaveInstanceState(outState);
        if (ivEscudo.getDrawable() != null) {
            fotoEscudo = ((BitmapDrawable) ivEscudo.getDrawable()).getBitmap();
        } else {
            fotoEscudo = null;
        }
        outState.putParcelable(IMAGEN_ESCUDO, fotoEscudo);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        ivEscudo.setImageBitmap(savedInstanceState.getParcelable(IMAGEN_ESCUDO));
    }


    /**
     * Método que se ejecuta al pulsar botón Añadir Foto y añadir equipo
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        int idBoton = v.getId();
        if (idBoton == R.id.btAniadirFoto) {
            tomarFoto();
        } else {
            aniadirEquipo();
        }
    }
}