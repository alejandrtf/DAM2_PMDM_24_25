package com.example.ejemplorecyclerview2024.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ejemplorecyclerview2024.R;
import com.example.ejemplorecyclerview2024.model.Equipo;

public class VerEquipoActivity extends AppCompatActivity {
    // CONSTANTS
    public final static String EXTRA_POSICION="extra posicion";

    // VIEWS
    private ImageView ivEscudo;
    private TextView tvNombre,tvPuntos,tvNumeroJugadores;

    // VARIABLES
    private int posicionEquipo;

    // OBJETOS
    private Equipo equipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ver_equipo);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initReferences();
        // recojo la posición del equipo que debe ser mostrado
        if(getIntent().hasExtra(EXTRA_POSICION)){
            posicionEquipo=getIntent().getIntExtra(EXTRA_POSICION,-1);
        }

        if(posicionEquipo!=-1){
            equipo=MainActivity.listaEquipos.get(posicionEquipo);
        }
        actualizarUI(equipo);

    }



    /** Método que obtiene las referencias a las vistas del XML
     *
     */
    private void initReferences() {
        ivEscudo=findViewById(R.id.ivEscudoDetalle);
        tvNombre=findViewById(R.id.tvNombreDetalle);
        tvPuntos=findViewById(R.id.tvPuntosDetalle);
        tvNumeroJugadores=findViewById(R.id.tvNumeroJugadores);
    }


    /** Muestra en la pantalla el equipo cuyos datos se pasan
     *
     * @param equipo objeto Equipo que se muestra en pantalla
     */
    private void actualizarUI(Equipo equipo) {
        ivEscudo.setImageDrawable(equipo.getEscudo());
        tvNombre.setText(equipo.getNombre());
        tvPuntos.setText(String.valueOf(equipo.getPuntos()));
        tvNumeroJugadores.setText(String.valueOf(equipo.getNumeroJugadores()));
    }
}